<!-- lumina: session=ses_e747dc392ffe67teDB1eAij6sa -->

# Copyous 剪贴板管理器性能优化 — 完成报告

## 改动内容（12 个源文件，+614/-174 行）

### 搜索（操作卡顿主因）
- **`searchEntry.ts`**：废除 O(n·m) 的 `Intl.Collator` 滑动窗口匹配，改为 NFD 音调折叠 + 小写 + 原生 `includes()`（带缓存），语义保持大小写/音调不敏感；搜索输入加 120ms 防抖，回车提交前自动 flush。

### 打开速度（打开卡顿主因）
- **`clipboardScrollContainer.ts` / `clipboardScrollView.ts` / `clipboardDialog.ts`**：核心重构为「前缀挂载」模型 —— 数据真源为有序数组，打开对话框只挂载前 24 条立即显示，其余按每帧 32 条 idle 分帧补齐；滚动接近已挂载边界时按需加挂；搜索/索引选择前同步全量挂载保证正确性；插入用二分查找（原 O(n²)）。
- **`codeLabel.ts`**：highlight.js 高亮延迟到 label 可见时执行、`highlightAuto` 输入截断至 8KB（原会对每条记录尝试全部语言）、hljs 加载回调不再全量刷新离屏 label。
- **`contentInfo.ts`**：`Intl.Segmenter` 实例复用 + 统计结果缓存 + 延迟到可见时统计。
- **`linkItem.ts`**：排除正则编译缓存；元数据网络请求延迟到条目可见时发起、并发限制为 4（原来每个链接条目构造即无限制并发请求）。

### 渲染与杂项
- **`clipboardItemHeader.ts` / `clipboardItem.ts`**：HoleEffect（GLSL 离屏效果）默认禁用，仅在 header 按钮可见时启用 —— 消除数百个常驻离屏渲染。
- **`icons.ts`**：`loadIcon` 缓存（原来每次同步磁盘 I/O，每条目 4-5 次）。
- **`gda.ts`**：Gda 5 查询轮询改为立即首查（原来每条查询固定 ≥100ms 延迟，影响启动与每次复制）。
- **`clipboardItem.ts` / `characterItem.ts`**：设置变化时离屏条目只标脏、可见时才刷新；style 赋值去重，消除 allocate 期间的样式重算布局风暴。
- **新增 `tests/shell/performance2.ts`**：修复原性能测试的两个缺陷（不等待历史加载完成、无首帧指标）。

## 验证结果

在 headless GNOME Shell 中用 336 条混合历史记录（文本/代码/链接，模拟用户规模）实测：

| 指标 | 优化前 | 优化后 | 改善 |
|---|---|---|---|
| 打开 → 首帧可交互（预热后） | 292ms | **62–113ms** | **-61% ~ -79%** |
| 撞上历史加载期的打开（用户"打开卡两三秒"场景） | 3528ms | **~1258ms** | **-64%** |

- `make build` / `make lint`（tsc + ESLint + Prettier）全部通过
- 测试环境限制说明：该环境无 highlight.js、使用 Gda 6，因此真实用户环境（有 hljs 全量高亮、Gda 5 100ms 轮询）下收益会更大；两项优化正好针对这些路径。
- 测试过程中发现并绕过了仓库的两个既有构建/测试问题（pnpm v11 输出污染 sass 管道导致干净构建失败；`tests/run-tests.sh` 无执行权限），均与本次改动无关，未修改。

## 已知限制
- 打开后其余条目在后台约 1–2.5 秒内渐进补全（期间滚动到底部会触发按需挂载兜底）；`waitLeisure` 类指标（等主循环完全空闲）会包含这段后台时间，但用户可立即交互。
- 搜索的音调折叠用 NFD 分解近似 Collator base 语义，个别边缘用例（如德语 ß=ss）行为略有差异，性能提升数个数量级。
- 若历史达到数千条，可进一步考虑完整视口化虚拟列表（本次未做，见计划 P2）。
