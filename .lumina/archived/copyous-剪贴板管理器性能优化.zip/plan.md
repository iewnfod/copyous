<!-- lumina: session=ses_e747dc392ffe67teDB1eAij6sa -->

# 性能诊断报告与优化计划

## 一、诊断结论：卡在哪里

### 🔴 瓶颈 1：300 条记录 = 全量创建 ~6000 个 Actor，常驻场景图（"打开卡 2-3 秒"的根源）

`extension.ts → initEntryTracker()` 启动时循环调用 `clipboardDialog.addEntry()`，为**每条**记录创建完整 item。每个 item 的 actor 树包括：按钮本体 + box + header（图标、标题、时间、3 个按钮各带图标、tag 图标 ≈ 10+ 个 actor）+ content 容器 + 内容组件 ≈ **15-25 个 actor/条**，300 条 ≈ 6000 个 actor 全部常驻 `modalDialogGroup`。

打开对话框 `show()` 时这 6000 个 actor 要在**一两帧内**完成 map + CSS 主题节点解析 + Pango 文本布局 + 首次分配 —— 这就是卡 2-3 秒的主体。

### 🔴 瓶颈 2：搜索函数是 O(n·m) 的 Collator 滑动窗口（"操作很卡"的最大原因）

`searchEntry.ts` 的 `localeContains()`：
```js
for (let offset = 0; offset <= text.length - query.length; offset++) {
    collator.compare(text.substring(offset, offset + query.length), query)  // 每步：字符串分配 + locale 比较
}
```
每敲一个字符 → `search()` → 300 个 item 逐个跑这个函数。剪贴板内容常有几 KB 长文本，一次按键可触发**百万级** `collator.compare` 调用 + 临时字符串分配。另外 `ClipboardDialog` 构造时还会全量跑一次 search。

### 🔴 瓶颈 3：每个 item 创建时同步执行昂贵工作

| 位置 | 问题 |
|---|---|
| `codeLabel.ts` | 无语言元数据时 `hljs.highlightAuto()` 尝试**所有**注册语言，大代码段每条几百 ms；且 hljs 异步加载完成后通过回调对**全部 300 条**重跑高亮 |
| `contentInfo.ts` | `TextInfo` 每次都 `new Intl.Segmenter()` 并对**全文**做 grapheme/word 分段统计 |
| `contentPreview.ts` | `ImagePreview` 构造时**同步**读图片尺寸、超大图同步缩放并保存 PNG |
| `linkItem.ts` | 每个实例都 `new RegExp(patterns.join('\|'))` 重新编译正则；无 metadata 的每个链接都发起网络请求，**无并发限制** |
| `icons.ts` | `loadIcon()` 每次调用同步 `query_exists()` 磁盘 I/O，每个 item 4-5 次 |
| `characterItem.ts` | `vfunc_allocate` 里每次分配都 `set_style()` → 主题重算 → 再触发 relayout（布局风暴风险） |

### 🟠 瓶颈 4：Gda5 数据库每条查询至少延迟 100ms

`gda.ts` 的 `async_statement_execute_select/non_select` 在 Gda 5 路径用 `timeout_add(100ms)` 轮询结果——**每条查询至少 100ms**。启动链（建表/版本查询/entries/deleteOldest）≥ 4 条查询 = 300-400ms 纯等待；每次复制新内容（selectConflict + insert + deleteOldest）又是 3 条 = 300ms+。

### 🟠 瓶颈 5：布局与信号放大

- `insertOrMoveItem()`：每次插入都 remove + 线性扫描比较 datetime，批量加载是 **O(n²)**（300 条 ≈ 45000 次比较）
- 每个 item 连接 8 个 settings 信号（共 2400+），任何设置变化触发 300 个回调，各自 `get_int` + `set_size` + `style=` 赋值（触发主题节点重算）
- `HoleEffect` 是常驻启用的 GLSL offscreen 效果——每个 item 一直进行离屏渲染，滚动时尤其昂贵
- 每 item 还有 6 个 entry 信号 + tracker 7 个信号，信号连接总数上万

## 二、优化方案（按性价比排序）

### P0：小改动、立竿见影

1. **重写搜索匹配**（`searchEntry.ts`）
   - `localeContains` 改为：先把 query 和 text 用 `toLocaleLowerCase()` 归一化（Segmenter/Collator 语义足够近似，保留大小写不敏感），再用原生 `includes()`（C++ 实现，快几个数量级）
   - 搜索输入加 ~120ms 防抖（`notify::text` 用 timeout 合并）

2. **图标缓存**（`icons.ts`）：模块级 `Map<Icon, Gio.Icon>`，消除每 item 4-5 次同步磁盘 I/O

3. **Gda5 查询立即首查**（`gda.ts`）：轮询前先立即（idle）检查一次结果，之后才 100ms 轮询——单查询延迟从 ≥100ms 降到通常 ~0ms

4. **代码高亮降载**（`codeLabel.ts`）
   - `highlightAuto` 输入截断（如前 8KB），避免整段大文本跑全语言检测
   - hljs 初始化完成回调只刷新当前已 map（可见）的 label，其余等 map 时再高亮
   - `applyTheme` 的正则替换保持，但只在文本实际变化时执行

5. **延迟昂贵统计与网络**（`contentInfo.ts`、`linkItem.ts`）
   - `Intl.Segmenter` 实例提到模块级复用；统计结果按文本缓存，仅 item 可见（map）时或内容变化时重算
   - LinkItem 排除正则模块级缓存（按 patterns 内容）；`tryGetMetadata` 增加并发上限（如同时 4 个），只对可见 item 请求

6. **HoleEffect 按需启用**（`clipboardItem.ts` / `holeEffect.ts`）：效果默认 `enabled=false`，仅在 header 按钮区域可见（hover/focus/pinned 状态切换）时启用，消除 300 个常驻离屏渲染

### P1：结构性改进（中等改动）

7. **分帧创建 item**（`extension.ts` + `clipboardScrollContainer.ts`）
   - 打开对话框时先立即创建首屏数量（如 24 个），其余用 `GLib.idle_add` 每帧一批（16-24 个）在后台补齐——打开瞬间即可交互
   - 批量加载时利用数据库已按 datetime 排序的特点直接顺序 append（新增快速路径，消除 O(n²) 插入）；仅单个新条目（复制动作）才走完整插入逻辑

8. **设置信号瘦身**（`clipboardItem.ts` 等）：设置读取合并——单一全局 listener 读一次值，通过自定义信号/回调广播给 item；item 端避免重复 `style=` 赋值（先比较再赋值）

9. **insertOrMoveItem 二分查找**：children 按 datetime 有序，用二分定位插入点，单条插入从 O(n) 降到 O(log n)

### P2（可选，本次不做）：视口化虚拟列表
只实例化可见区域 ± 缓冲的 item、滚动时复用。可支撑数千条记录，但与现有焦点导航/搜索/右键菜单架构耦合深，改动风险大。若 P0+P1 落地后 300-500 条已流畅，可暂不做。

## 三、不改变行为的承诺
- 搜索语义（大小写不敏感、pinned/tag/type 过滤、增量搜索优化）保持不变，只优化匹配实现
- 视觉效果（洞效果、hover 亮度）保持一致，只是按需启用
- 数据库 schema 与设置不变

## 四、验证方式
- `make build` + `make lint` + `make test` 通过
- 手动验证：打开对话框耗时明显下降（可加临时计时日志）；输入搜索逐字无卡顿；滚动流畅；复制新条目即时出现在列表头；pin/删除/编辑/右键菜单正常
